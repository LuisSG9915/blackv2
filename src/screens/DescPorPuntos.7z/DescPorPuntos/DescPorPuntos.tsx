import React, { useState, useEffect } from "react";
import { AiOutlineUser, AiFillEdit, AiFillDelete } from "react-icons/ai";
import { Row, Container, Card, CardHeader, CardBody, CardTitle, CardText, Input, Table, FormGroup, Modal, ModalBody, ModalFooter, ModalHeader, Label } from "reactstrap";
import CButton from "../../components/CButton";
import SidebarHorizontal from "../../components/SideBarHorizontal";
import { useNavigate } from "react-router-dom";
import { jezaApi } from "../../api/jezaApi";
import useModalHook from "../../hooks/useModalHook";
import { DescPorPunto } from "../../models/DescPorPunto";
import { useSucursales } from "../../hooks/getsHooks/useSucursales";
import { Sucursal } from "../../models/Sucursal";
import { useFormasPagos } from "../../hooks/getsHooks/useFormasPagos";
import { FormaPago } from "../../models/FormaPago";

function DescPorPuntos() {
  const { modalActualizar, modalInsertar, setModalInsertar, setModalActualizar, cerrarModalActualizar, cerrarModalInsertar, mostrarModalInsertar } = useModalHook();
  const [data, setData] = useState([]);
  const { dataSucursales } = useSucursales();
  const { dataFormasPagos } = useFormasPagos();

  const [form, setForm] = useState<DescPorPunto>({
    ID: 1,
    cia: 1,
    area: 1,
    depto: 1,
    forma_pago: 1,
    sucursal: 1,
    porcentaje_puntos: 1,
  });

  const DataTableHeader = ["Sucursal", "Area", "Departamento", "Forma de pago", "Porcentaje", "acciones"];

  const mostrarModalActualizar = (dato: DescPorPunto) => {
    setForm(dato);
    setModalActualizar(true);
  };

  const editar = (dato: any) => {
    jezaApi
      .put(`/DeptosPuntos`, null, {
        /* <-----------------------------------------------------------------------------------------API EDITAR */
        params: {
          id: form.ID,
          cia: 1,
          area: 1,
          depto: 1,
          forma_pago: form.forma_pago,
          sucursal: form.sucursal,
          porcentaje_puntos: form.porcentaje_puntos,
        },
      })
      .then(() => {
        getDesucentos();
      })
      .catch((e) => console.log(e));
    const arreglo: any[] = [...data];
    const index = arreglo.findIndex((registro) => registro.id === dato.id);
    if (index !== -1) {
      console.log("index");
      setModalActualizar(false);
    }
  };

  const eliminar = (dato: DescPorPunto) => {
    console.log(dato);
    const opcion = window.confirm(`Estás Seguro que deseas Eliminar el elemento ${dato.ID}`);
    if (opcion) {
      jezaApi.delete(`/DeptosPuntos?id=${dato.ID}`).then(() => {
        setModalActualizar(false);
        getDesucentos();
      });
    }
  };

  const getDesucentos = () => {
    jezaApi
      .get("/DeptosPuntos?id=0")
      .then((response) => {
        setData(response.data);
      })
      .catch((e) => console.log(e));
  };
  useEffect(() => {
    getDesucentos();
  }, []);

  const insertar = () => {
    jezaApi
      .post("/DeptosPuntos", null, {
        params: {
          cia: 1,
          area: 1,
          depto: 1,
          forma_pago: 13,
          sucursal: 1,
          porcentaje_puntos: Number(form.porcentaje_puntos),
        },
      })
      .then((r) => {
        console.log("exitoso");
        console.log(r);
      })
      .catch((e) => console.log(e));
    setModalInsertar(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prevState: any) => ({ ...prevState, [name]: value }));
    console.log(form);
  };

  const [isSidebarVisible, setSidebarVisible] = useState(false);

  const toggleSidebar = () => {
    setSidebarVisible(!isSidebarVisible);
  };

  return (
    <>
      <Row>
        <SidebarHorizontal />
      </Row>
      <Container>
        <br />
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <h1> Configuración de puntos y recompensas </h1>
          <AiOutlineUser size={30} />
        </div>
        <br />
        <Container className="d-flex justify-content-end ">
          <CButton color="success" onClick={() => mostrarModalInsertar()} text="Nuevo Registro" />
        </Container>
        <br />

        <Table size="sm" striped={true} responsive={true} style={{ width: "70%", margin: "auto" }}>
          <thead>
            <tr>
              {DataTableHeader.map((valor) => (
                <th className="" key={valor}>
                  {valor}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((dato: DescPorPunto) => (
              <tr key={dato.ID}>
                <td>{dato.sucursal}</td>
                <td>{dato.area}</td>
                <td>{dato.depto}</td>
                <td>{dato.forma_pago}</td>
                <td>{dato.porcentaje_puntos}</td>

                <td style={{ width: 20 }}>
                  <AiFillEdit className="mr-2" onClick={() => mostrarModalActualizar(dato)} size={23}></AiFillEdit>
                  <AiFillDelete color="lightred" onClick={() => eliminar(dato)} size={23}></AiFillDelete>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Container>

      <Modal isOpen={modalActualizar} size="xl">
        <ModalHeader>
          <div>
            <h3>Editar Registro</h3>
          </div>
        </ModalHeader>

        <ModalBody>
          <Container>
            {/* <CFormGroupInput
              handleChange={handleChange}
              inputName="descripcion_perfil"
              labelName="Perfil:"
              value={form.descripcion_perfil}
            /> */}
            <Label for="sucursal">Sucursal:</Label>
            <Input type="select" name="sucursal" id="sucursal" onChange={handleChange}>
              {dataSucursales.map((sucursal: Sucursal) => (
                <option value={sucursal.sucursal}> {sucursal.nombre} </option>
              ))}
            </Input>

            <Input type="select" name="area" id="area" onChange={handleChange}>
              {/* Opciones de área */}
            </Input>

            <Label for="departamento">Departamento:</Label>
            <Input type="select" name="departamento" id="departamento" onChange={handleChange}>
              {/* Opciones de departamento */}
            </Input>

            <Label for="formaPago">Forma de Pago:</Label>
            <Input type="select" name="formaPago" id="formaPago" onChange={handleChange}>
              {/* Opciones de forma de pago */}
              {dataFormasPagos.map((formaPago: FormaPago) => (
                <option value={formaPago.tipo}> {formaPago.descripcion} </option>
              ))}
            </Input>

            <FormGroup>
              <Label for="Porcentaje">Porcentaje:</Label>
              <Input type="text" name="porcentaje_puntos" id="Porcentaje" onChange={handleChange} />
            </FormGroup>
          </Container>
        </ModalBody>

        <ModalFooter>
          <CButton
            color="primary"
            onClick={() => {
              editar(form);
              getDesucentos();
            }}
            text="Editar"
          />
          <CButton color="danger" onClick={() => cerrarModalActualizar()} text="Cancelar" />
        </ModalFooter>
      </Modal>

      <Modal isOpen={modalInsertar} about="">
        <ModalHeader>
          <div>
            <h3>Insertar </h3>
          </div>
        </ModalHeader>
        <ModalBody>
          <FormGroup>
            <Label for="sucursal">Sucursal:</Label>
            <Input type="select" name="sucursal" id="sucursal" onChange={handleChange}>
              {dataSucursales.map((sucursal: Sucursal) => (
                <option value={sucursal.sucursal}> {sucursal.nombre} </option>
              ))}
            </Input>
          </FormGroup>

          <FormGroup>
            <Label for="area">Area:</Label>
            <Input type="select" name="area" id="area" onChange={handleChange}>
              {/* Opciones de área */}
            </Input>
          </FormGroup>

          <FormGroup>
            <Label for="departamento">Departamento:</Label>
            <Input type="select" name="departamento" id="departamento" onChange={handleChange}>
              {/* Opciones de departamento */}
            </Input>
          </FormGroup>

          <FormGroup>
            <Label for="formaPago">Forma de Pago:</Label>
            <Input type="select" name="formaPago" id="formaPago" onChange={handleChange}>
              {/* Opciones de forma de pago */}
              {dataFormasPagos.map((formaPago: FormaPago) => (
                <option value={formaPago.tipo}> {formaPago.descripcion} </option>
              ))}
            </Input>
          </FormGroup>

          <FormGroup>
            <Label for="Porcentaje">Porcentaje:</Label>
            <Input type="number" name="porcentaje_puntos" id="Porcentaje" onChange={handleChange} />
          </FormGroup>
        </ModalBody>
        <ModalFooter>
          <CButton color="primary" onClick={() => insertar()} text="Insertar" />
          <CButton color="btn btn-danger" onClick={() => cerrarModalInsertar()} text="Cancelar" />
        </ModalFooter>
      </Modal>
    </>
  );
}

export default DescPorPuntos;
